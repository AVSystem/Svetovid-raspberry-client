#!/usr/bin/env python

ACCELERATION_CONSTANT = 9.81
