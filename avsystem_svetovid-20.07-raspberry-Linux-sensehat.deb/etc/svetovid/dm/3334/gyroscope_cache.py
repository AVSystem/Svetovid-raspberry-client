#!/usr/bin/env python

from sense_hat import SenseHat

import cached_value


class GyroscopeCache(cached_value.CachedMinMaxValue):
    def __init__(self):
        super(GyroscopeCache, self).__init__(namespace=3334,
                                             getter=(
                                                 lambda: SenseHat().get_gyroscope_raw().values()),
                                             invalidate_after_s=5.0)
