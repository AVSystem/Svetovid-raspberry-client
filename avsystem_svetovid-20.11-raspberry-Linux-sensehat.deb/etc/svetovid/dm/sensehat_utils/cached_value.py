#!/usr/bin/env python

# Copyright ##year## AVSystem <avsystem@avsystem.com>
# AVSystem SVD
# Version ##version##
# ALL RIGHTS RESERVED

from fsdm import KvStore

import time
import sys


class CachedMinMaxValue(object):
    def __init__(self, namespace, getter, invalidate_after_s):
        self._namespace = namespace
        self._getter = getter
        self._invalidate_after_s = invalidate_after_s

    def _ensure_fresh_value(self):
        store = KvStore(self._namespace)
        now = time.time()

        if float(store.get('cached_at', 0.0)) + self._invalidate_after_s <= now:
            current_value = self._getter()
            cached_min = store.get('cached_min', current_value)
            cached_max = store.get('cached_max', current_value)

            keys_to_store = {
                'cached_at': now
            }
            if isinstance(current_value, tuple) \
                or isinstance(current_value, list):
                min_value = tuple(min(a, b) for a, b in zip(current_value, cached_min))
                max_value = tuple(max(a, b) for a, b in zip(current_value, cached_max))

                def apply_elementwise(a, b, op):
                    return [op(p, q) for (p, q) in zip(a, b)]

                keys_to_store.update({
                    'cached_value': current_value,
                    'cached_min': apply_elementwise(current_value, min_value, min),
                    'cached_max': apply_elementwise(current_value, max_value, max),
                })
            else:
                keys_to_store.update({
                    'cached_value': current_value,
                    'cached_min': min(current_value, cached_min),
                    'cached_max': max(current_value, cached_max),
                })

            store.set_many(keys_to_store)

    @property
    def value(self):
        self._ensure_fresh_value()
        return KvStore(self._namespace).get('cached_value')

    @property
    def min(self):
        self._ensure_fresh_value()
        return KvStore(self._namespace).get('cached_min')

    @property
    def max(self):
        self._ensure_fresh_value()
        return KvStore(self._namespace).get('cached_max')

    def reset(self):
        KvStore(self._namespace).delete('cached_at')
