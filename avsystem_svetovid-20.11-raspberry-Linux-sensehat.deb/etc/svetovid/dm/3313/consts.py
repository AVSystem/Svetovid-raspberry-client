#!/usr/bin/env python

# Copyright ##year## AVSystem <avsystem@avsystem.com>
# AVSystem SVD
# Version ##version##
# ALL RIGHTS RESERVED

ACCELERATION_CONSTANT = 9.81
