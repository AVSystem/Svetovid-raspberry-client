#!/usr/bin/env python

# Copyright ##year## AVSystem <avsystem@avsystem.com>
# AVSystem SVD
# Version ##version##
# ALL RIGHTS RESERVED

from sense_hat import SenseHat

import cached_value


class MagnetometerCache(cached_value.CachedMinMaxValue):
    @staticmethod
    def get_reading():
        sense = SenseHat()

        return sense.get_compass_raw().values() + [ sense.get_compass() ]

    def __init__(self):
        super(MagnetometerCache, self).__init__(namespace=3314,
                                                getter=MagnetometerCache.get_reading,
                                                invalidate_after_s=5.0)
