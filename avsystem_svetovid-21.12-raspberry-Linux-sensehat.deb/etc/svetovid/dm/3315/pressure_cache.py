#!/usr/bin/env python

# Copyright ##year## AVSystem <avsystem@avsystem.com>
# AVSystem SVD
# Version ##version##
# ALL RIGHTS RESERVED

from sense_hat import SenseHat

import cached_value


class PressureCache(cached_value.CachedMinMaxValue):
    def __init__(self):
        super(PressureCache, self).__init__(namespace=3315,
                                            getter=(
                                                lambda: SenseHat().get_pressure()),
                                            invalidate_after_s=5.0)
